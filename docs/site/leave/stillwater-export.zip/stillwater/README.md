# Stillwater Yoga

Everything of this app as of 2026-10-31 01:03 UTC.

This is a sample: the booking starter, with one page (`src/custom/pages/instructors.tsx`) made the
owner's own, exported the way smithable.ai's "Download everything" exports an app. Its records are
the starter's sample data, standing in for an app's real records. What to do with it, step by step:
https://docs.smithable.ai/leave.html

- `project.bundle`: the project's code with its whole Git history.
- `data/`: the data in Studio (the app is not published): the database (`db/app.db`, SQLite) and any uploaded files (`uploads/`). Sign-in sessions, codes and links are left out, so everyone signs in again.
- `tables/`: each table of that database as a CSV file, for a spreadsheet (not the sign-in tables or people's favorites). Dates are milliseconds since 1970, money is in cents.

## Open it

```sh
git clone project.bundle stillwater
cp -r data stillwater/
cd stillwater
pnpm install
smithable studio
```

It is an ordinary TypeScript app (TanStack Start, Drizzle, SQLite), so it also runs without Smithable: `pnpm dev`. `smithable detach` removes what only Smithable uses, leaving the changes for you to review and commit.
